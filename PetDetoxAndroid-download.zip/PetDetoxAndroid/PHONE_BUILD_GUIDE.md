# Build an installable APK using only an Android phone

This project includes `.github/workflows/android.yml`, but GitHub does not run a workflow stored inside an uploaded ZIP automatically. Follow the steps below once to create a private repository and add the workflow at the repository root.

1. In a browser on your phone, sign in to GitHub and create a **Private** repository named `PetDetoxAndroid`.
2. Open the new repository, choose **Add file → Upload files**, and upload `PetDetoxAndroid.zip` from Downloads. Commit the upload to `main`.
3. Choose **Add file → Create new file**. For the file name, enter `.github/workflows/android.yml` (the slashes create the folders).
4. Copy the complete contents of this project's `.github/workflows/android.yml` into the editor and commit to `main`.
5. Open the repository's **Actions** tab and open the latest **Build PetDetox APK** run. Wait for it to finish.
6. If successful, open the run and download the `PetDetox-debug-apk` artifact. GitHub downloads it as a ZIP; extract it with a file manager to get `app-debug.apk`.
7. Tap `app-debug.apk` and allow your browser/file manager to install unknown apps if Android asks. Only install APKs you built from your own repository.

If the build fails, open the run, expand the failed step, and share the error text. Do not share access tokens or passwords. The APK is a debug build for testing, not a Play Store release.
