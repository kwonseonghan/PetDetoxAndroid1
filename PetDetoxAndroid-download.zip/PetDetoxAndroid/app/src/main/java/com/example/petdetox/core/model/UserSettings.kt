package com.example.petdetox.core.model

data class UserSettings(
    val dailyGoalMinutes: Int = 240,
    val activeStartMinute: Int = 8 * 60,
    val activeEndMinute: Int = 23 * 60,
    val selectedAppPackages: Set<String> = emptySet(),
    val dailyAppLimitMinutes: Int = 60,
    val onboardingCompleted: Boolean = false,
    val petName: String = "새싹이",
    val settingsVersion: Int = 1,
)
