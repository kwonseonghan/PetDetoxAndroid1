package com.example.petdetox.feature.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.weight
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.example.petdetox.core.model.UserSettings
import com.example.petdetox.core.ui.components.SectionCard
import com.example.petdetox.core.ui.components.SettingRow
import com.example.petdetox.feature.app.InstalledAppChoice
import com.example.petdetox.platform.permissions.UsageAccessPermission
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect

@Composable
fun SettingsScreen(
    settings: UserSettings,
    apps: List<InstalledAppChoice>,
    onGoalChange: (Int) -> Unit,
    onAppLimitChange: (Int) -> Unit,
    onToggleApp: (String, Boolean) -> Unit,
    onPetNameChange: (String) -> Unit,
) {
    val context = LocalContext.current
    var usageAccessGranted by remember { mutableStateOf(UsageAccessPermission.isGranted(context)) }
    var goal by remember(settings.dailyGoalMinutes) { mutableFloatStateOf(settings.dailyGoalMinutes.toFloat()) }
    var appLimit by remember(settings.dailyAppLimitMinutes) { mutableFloatStateOf(settings.dailyAppLimitMinutes.toFloat()) }
    var petName by remember(settings.petName) { mutableStateOf(settings.petName) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        usageAccessGranted = UsageAccessPermission.isGranted(context)
    }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("설정", style = MaterialTheme.typography.headlineMedium)
        SectionCard {
            Text("나의 목표", style = MaterialTheme.typography.titleLarge)
            Text("하루 디톡스 목표 · ${goal.toInt()}분", style = MaterialTheme.typography.bodyMedium)
            Slider(
                value = goal,
                onValueChange = { goal = it },
                valueRange = 60f..480f,
                steps = 13,
                onValueChangeFinished = { onGoalChange(goal.toInt()) },
            )
            SettingRow("활동 시간", "디톡스 시간을 계산할 시간대", "08:00–23:00")
            OutlinedTextField(
                value = petName,
                onValueChange = { petName = it.take(12) },
                label = { Text("펫 이름") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
            )
            TextButton(onClick = { onPetNameChange(petName) }, modifier = Modifier.align(Alignment.End)) { Text("이름 저장") }
        }
        SectionCard {
            Text("방해 앱", style = MaterialTheme.typography.titleLarge)
            Text("선택한 앱을 사용한 시간은 성장 효율 계산에 반영돼요.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("일일 사용 한도 · ${appLimit.toInt()}분", style = MaterialTheme.typography.bodyMedium)
            Slider(
                value = appLimit,
                onValueChange = { appLimit = it },
                valueRange = 0f..240f,
                steps = 11,
                onValueChangeFinished = { onAppLimitChange(appLimit.toInt()) },
            )
            if (apps.isEmpty()) {
                Text("앱 목록을 불러오지 못했어요. 기기에서 앱 목록을 확인해 주세요.", style = MaterialTheme.typography.bodySmall)
            } else {
                apps.forEach { app ->
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = app.packageName in settings.selectedAppPackages,
                            onCheckedChange = { onToggleApp(app.packageName, it) },
                        )
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(app.label, style = MaterialTheme.typography.bodyMedium)
                            Text(app.packageName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        SectionCard {
            Text("권한 및 데이터", style = MaterialTheme.typography.titleLarge)
            SettingRow(
                "사용 기록 권한",
                "화면이 꺼진 시간과 앱 사용 시간을 측정합니다",
                if (usageAccessGranted) "연결됨" else "설정 열기",
                onClick = { UsageAccessPermission.openSettings(context) },
            )
            Text("측정값은 이 기기에만 저장됩니다. 앱을 삭제하거나 기기 데이터를 지우면 기록이 사라질 수 있어요.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
