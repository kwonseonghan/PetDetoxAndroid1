package com.example.petdetox.domain.growth

/** Three evolution transitions: egg -> baby -> growing -> adult. */
enum class EvolutionStage(val displayName: String, val thresholdXp: Int) {
    EGG("알", 0),
    BABY("아기", 100),
    GROWING("성장기", 300),
    ADULT("성체", 700),
}

data class PetProgress(
    val stage: EvolutionStage,
    val currentStageThresholdXp: Int,
    val nextStageThresholdXp: Int?,
    val xpUntilNextStage: Int,
    val progressToNextStage: Float,
)

object PetProgression {
    fun stageFor(totalXp: Long): EvolutionStage {
        require(totalXp >= 0L) { "totalXp must not be negative" }
        return when {
            totalXp >= EvolutionStage.ADULT.thresholdXp -> EvolutionStage.ADULT
            totalXp >= EvolutionStage.GROWING.thresholdXp -> EvolutionStage.GROWING
            totalXp >= EvolutionStage.BABY.thresholdXp -> EvolutionStage.BABY
            else -> EvolutionStage.EGG
        }
    }

    fun progressFor(totalXp: Long): PetProgress {
        val stage = stageFor(totalXp)
        val currentThreshold = stage.thresholdXp
        val nextThreshold = when (stage) {
            EvolutionStage.EGG -> EvolutionStage.BABY.thresholdXp
            EvolutionStage.BABY -> EvolutionStage.GROWING.thresholdXp
            EvolutionStage.GROWING -> EvolutionStage.ADULT.thresholdXp
            EvolutionStage.ADULT -> null
        }

        if (nextThreshold == null) {
            return PetProgress(
                stage = stage,
                currentStageThresholdXp = currentThreshold,
                nextStageThresholdXp = null,
                xpUntilNextStage = 0,
                progressToNextStage = 1f,
            )
        }

        val current = totalXp.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        val xpInStage = (current - currentThreshold).coerceAtLeast(0)
        val stageSpan = nextThreshold - currentThreshold
        return PetProgress(
            stage = stage,
            currentStageThresholdXp = currentThreshold,
            nextStageThresholdXp = nextThreshold,
            xpUntilNextStage = (nextThreshold - current).coerceAtLeast(0),
            progressToNextStage = (xpInStage.toFloat() / stageSpan).coerceIn(0f, 1f),
        )
    }
}
