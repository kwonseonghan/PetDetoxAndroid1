package com.example.petdetox.feature.statistics

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.petdetox.core.ui.components.SectionCard
import com.example.petdetox.core.ui.components.StatValue
import com.example.petdetox.data.local.entity.DailyStatsEntity

@Composable
fun StatisticsScreen(stats: List<DailyStatsEntity>, dailyGoalMinutes: Int) {
    val ordered = stats.sortedBy(DailyStatsEntity::dateKey).takeLast(7)
    val valid = ordered.filter { it.isFinalized && it.nonUseMinutes != null }
    val total = valid.sumOf { it.nonUseMinutes ?: 0 }
    val average = if (valid.isEmpty()) 0 else total / valid.size
    val goalDays = valid.count { (it.nonUseMinutes ?: 0) >= dailyGoalMinutes }
    val maxMinutes = (ordered.maxOfOrNull { it.nonUseMinutes ?: 0 } ?: 0).coerceAtLeast(1)

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("나의 기록", style = MaterialTheme.typography.headlineMedium)
        SectionCard {
            Text("최근 기록", style = MaterialTheme.typography.titleLarge)
            if (ordered.isEmpty()) {
                Text("아직 확정된 기록이 없어요. 활동 시간이 끝나고 측정이 완료되면 기록이 쌓여요.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(
                modifier = Modifier.fillMaxWidth().height(160.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                ordered.forEach { day ->
                    val minutes = if (day.isFinalized) day.nonUseMinutes ?: 0 else 0
                    val barHeight = if (minutes == 0) 4 else (100f * minutes / maxMinutes).toInt().coerceIn(4, 100)
                    Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(if (minutes > 0) minutes.toString() else "—", style = MaterialTheme.typography.labelSmall)
                        Box(
                            modifier = Modifier.width(22.dp).height(barHeight.dp)
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = if (minutes > 0) 0.75f else 0.15f), RoundedCornerShape(8.dp)),
                        )
                        Text(day.dateKey.takeLast(5), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        SectionCard {
            Text("기록 요약", style = MaterialTheme.typography.titleLarge)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                StatValue("총 휴식", "${total}분")
                StatValue("일평균", if (valid.isEmpty()) "—" else "${average}분")
                StatValue("목표 달성", if (valid.isEmpty()) "—" else "${goalDays}일")
            }
            Text("완료된 측정만 집계합니다. 목표 달성 일수는 현재 설정한 ${dailyGoalMinutes}분 기준입니다.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
