package com.example.petdetox.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pet_state")
data class PetStateEntity(
    @PrimaryKey val id: Int = SINGLE_PET_ID,
    val totalXp: Long = 0L,
    val level: Int = 1,
    val evolutionStage: String = "EGG",
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
) {
    companion object {
        const val SINGLE_PET_ID = 1
    }
}
