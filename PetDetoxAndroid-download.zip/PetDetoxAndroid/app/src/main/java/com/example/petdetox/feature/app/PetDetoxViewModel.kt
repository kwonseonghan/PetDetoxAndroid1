package com.example.petdetox.feature.app

import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.petdetox.core.model.UserSettings
import com.example.petdetox.data.local.entity.DailyStatsEntity
import com.example.petdetox.data.local.entity.PetStateEntity
import com.example.petdetox.data.local.entity.UsageSnapshotEntity
import com.example.petdetox.data.repository.PetDetoxRepository
import com.example.petdetox.platform.usage.MeasurementIssue
import com.example.petdetox.platform.usage.MeasurementStatus
import com.example.petdetox.platform.usage.UsageMeasurementResult
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

data class InstalledAppChoice(val packageName: String, val label: String)

class PetDetoxViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = PetDetoxRepository(application)
    private val settingsMutex = Mutex()
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()
    private val _isMeasuring = MutableStateFlow(false)
    val isMeasuring: StateFlow<Boolean> = _isMeasuring.asStateFlow()
    private val _installedApps = MutableStateFlow<List<InstalledAppChoice>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppChoice>> = _installedApps.asStateFlow()

    val settings: StateFlow<UserSettings> = repository.settings.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000), UserSettings(),
    )
    val petState: StateFlow<PetStateEntity?> = repository.petState.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000), null,
    )
    val recentDailyStats: StateFlow<List<DailyStatsEntity>> = repository.recentDailyStats.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList(),
    )
    val latestUsageSnapshot: StateFlow<UsageSnapshotEntity?> = repository.latestUsageSnapshot.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000), null,
    )

    init {
        viewModelScope.launch { repository.ensurePetExists() }
        loadInstalledApps()
    }

    fun completeOnboarding(goalMinutes: Int) = updateSettings { it.copy(dailyGoalMinutes = goalMinutes, onboardingCompleted = true) }
    fun updateGoal(goalMinutes: Int) = updateSettings { it.copy(dailyGoalMinutes = goalMinutes) }
    fun updatePetName(name: String) = updateSettings { it.copy(petName = name.trim().ifBlank { "새싹이" }) }
    fun updateAppLimit(minutes: Int) = updateSettings { it.copy(dailyAppLimitMinutes = minutes) }
    fun toggleApp(packageName: String, selected: Boolean) = updateSettings {
        val apps = if (selected) it.selectedAppPackages + packageName else it.selectedAppPackages - packageName
        it.copy(selectedAppPackages = apps)
    }

    private fun updateSettings(transform: (UserSettings) -> UserSettings) {
        viewModelScope.launch {
            settingsMutex.withLock {
                runCatching { repository.saveSettings(transform(repository.settings.first())) }
                    .onFailure { _message.value = "설정을 저장하지 못했어요. 다시 시도해 주세요." }
            }
        }
    }

    fun refreshMeasurement() {
        if (!_isMeasuring.compareAndSet(false, true)) return
        viewModelScope.launch {
            try {
                val result = repository.measureAndStoreUsage()
                _message.value = result.toUserMessage()
            } catch (_: Exception) {
                _message.value = "측정에 실패했어요. 사용 기록 권한과 기기 설정을 확인해 주세요."
            } finally {
                _isMeasuring.value = false
            }
        }
    }

    fun dismissMessage() { _message.value = null }

    private fun loadInstalledApps() {
        viewModelScope.launch {
            val pm = getApplication<Application>().packageManager
            val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val choices = runCatching {
                pm.queryIntentActivities(launcherIntent, PackageManager.MATCH_ALL)
                    .mapNotNull { info ->
                        val packageName = info.activityInfo?.packageName ?: return@mapNotNull null
                        if (packageName == getApplication<Application>().packageName) return@mapNotNull null
                        InstalledAppChoice(packageName, info.loadLabel(pm).toString())
                    }
                    .distinctBy(InstalledAppChoice::packageName)
                    .sortedBy { it.label.lowercase() }
            }.getOrDefault(emptyList())
            _installedApps.value = choices
        }
    }

    private fun UsageMeasurementResult.toUserMessage(): String = when {
        status == MeasurementStatus.UNAVAILABLE && issue == MeasurementIssue.USAGE_ACCESS_NOT_GRANTED ->
            "사용 기록 권한이 필요해요. 설정에서 권한을 허용한 뒤 다시 측정해 주세요."
        issue == MeasurementIssue.WINDOW_NOT_STARTED -> "설정한 활동 시간이 시작되면 측정할 수 있어요."
        status == MeasurementStatus.UNAVAILABLE -> "측정할 수 없어요. 권한과 기기 사용 기록 설정을 확인해 주세요."
        status == MeasurementStatus.PARTIAL && nonUseMinutes == null -> "기록이 충분하지 않아 아직 확정할 수 없어요. 잠시 후 다시 측정해 주세요."
        status == MeasurementStatus.PARTIAL -> "현재까지 ${nonUseMinutes ?: 0}분을 측정했어요. 하루 정산은 활동 시간이 끝난 뒤 진행돼요."
        else -> "오늘 측정 완료! ${nonUseMinutes ?: 0}분의 디톡스 시간을 확인했어요."
    }
}
