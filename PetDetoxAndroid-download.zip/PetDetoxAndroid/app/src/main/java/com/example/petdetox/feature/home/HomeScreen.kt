package com.example.petdetox.feature.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.weight
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.petdetox.core.model.UserSettings
import com.example.petdetox.core.ui.components.PetIllustration
import com.example.petdetox.core.ui.components.PrimaryButton
import com.example.petdetox.core.ui.components.SectionCard
import com.example.petdetox.core.ui.components.StatValue
import com.example.petdetox.core.ui.components.XpProgressBar
import com.example.petdetox.data.local.entity.PetStateEntity
import com.example.petdetox.data.local.entity.UsageSnapshotEntity
import com.example.petdetox.domain.growth.PetProgression
import com.example.petdetox.platform.usage.MeasurementStatus
import java.time.LocalDate
import java.time.ZoneId

@Composable
fun HomeScreen(
    settings: UserSettings,
    pet: PetStateEntity?,
    snapshot: UsageSnapshotEntity?,
    isMeasuring: Boolean,
    onRefresh: () -> Unit,
) {
    val todayStart = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
    val todaySnapshot = snapshot?.takeIf { it.periodStartMillis >= todayStart && it.periodStartMillis < todayStart + 24L * 60 * 60 * 1000 }
    val nonUse = todaySnapshot?.nonUseMinutes
    val distraction = todaySnapshot?.distractionAppMinutes
    val totalXp = pet?.totalXp ?: 0L
    val progress = PetProgression.progressFor(totalXp)
    val currentStageXp = (totalXp - progress.currentStageThresholdXp).coerceAtLeast(0).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
    val nextStageSpan = progress.nextStageThresholdXp?.minus(progress.currentStageThresholdXp)

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("오늘도 천천히, 괜찮아요", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("나의 작은 친구", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
        SectionCard {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(settings.petName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("${progress.stage.displayName} 친구 · Lv. ${pet?.level ?: 1}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("휴대폰을 내려놓는 만큼 함께 자라요.", style = MaterialTheme.typography.bodySmall)
                }
                PetIllustration(size = 124.dp)
            }
            XpProgressBar(currentXp = currentStageXp, nextLevelXp = nextStageSpan)
            Text(
                if (progress.nextStageThresholdXp == null) "누적 경험치 ${totalXp} XP · 최종 성장 단계"
                else "누적 경험치 ${totalXp} XP · ${progress.xpUntilNextStage} XP 후 다음 성장",
                style = MaterialTheme.typography.bodySmall,
            )
        }
        SectionCard {
            Text("오늘의 휴식", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                StatValue("디톡스 시간", nonUse?.let { "${it}분" } ?: "—")
                StatValue("하루 목표", "${settings.dailyGoalMinutes}분")
                StatValue("방해 앱", distraction?.let { "${it}분" } ?: "—")
            }
            val statusText = when (todaySnapshot?.measurementStatus) {
                MeasurementStatus.COMPLETE.name -> "오늘 측정 완료"
                MeasurementStatus.PARTIAL.name -> "측정 중 · 활동 시간이 끝나면 정산돼요"
                MeasurementStatus.UNAVAILABLE.name -> "측정 불가 · 사용 기록 권한을 확인해 주세요"
                else -> "사용 기록을 측정해 오늘의 휴식 시간을 확인하세요."
            }
            Text(statusText, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            PrimaryButton(text = if (isMeasuring) "측정 중…" else "지금 측정하기", onClick = onRefresh, enabled = !isMeasuring)
        }
        SectionCard {
            Text("측정 안내", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text("활동 시간 ${settings.activeStartMinute / 60}:${(settings.activeStartMinute % 60).toString().padStart(2, '0')}–${settings.activeEndMinute / 60}:${(settings.activeEndMinute % 60).toString().padStart(2, '0')}", style = MaterialTheme.typography.bodyMedium)
            Text("화면이 꺼진 시간과 선택한 앱의 사용 시간을 기기 안에서 집계합니다. 원시 사용 기록은 저장하지 않습니다.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
