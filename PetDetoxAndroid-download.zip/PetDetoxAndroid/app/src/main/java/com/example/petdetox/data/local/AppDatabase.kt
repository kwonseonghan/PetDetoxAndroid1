package com.example.petdetox.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.petdetox.data.local.dao.DailyStatsDao
import com.example.petdetox.data.local.dao.PetStateDao
import com.example.petdetox.data.local.dao.UsageSnapshotDao
import com.example.petdetox.data.local.entity.DailyStatsEntity
import com.example.petdetox.data.local.entity.PetStateEntity
import com.example.petdetox.data.local.entity.UsageSnapshotEntity

@Database(
    entities = [PetStateEntity::class, DailyStatsEntity::class, UsageSnapshotEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun petStateDao(): PetStateDao
    abstract fun dailyStatsDao(): DailyStatsDao
    abstract fun usageSnapshotDao(): UsageSnapshotDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "pet_detox.db",
            ).build().also { instance = it }
        }
    }
}
