package com.example.petdetox.domain.usage

/** Platform-neutral event representation, allowing the interval logic to be tested without Android. */
enum class UsageEventKind { SCREEN_ON, SCREEN_OFF, APP_FOREGROUND, APP_BACKGROUND }

data class UsageEventRecord(
    val timestampMillis: Long,
    val kind: UsageEventKind,
    val packageName: String? = null,
)

data class UsageIntervalTotals(
    val nonUseMillis: Long,
    val distractingAppMillis: Long,
    val initialScreenStateKnown: Boolean,
)

/**
 * Reduces a chronologically ordered UsageEvents stream into totals clipped to [windowStartMillis,
 * windowEndMillis]. Screen-off time is counted as non-use; selected-app time is counted only while
 * the screen is interactive. The caller must provide events before the window to infer initial state.
 */
object UsageEventReducer {
    fun reduce(
        events: List<UsageEventRecord>,
        windowStartMillis: Long,
        windowEndMillis: Long,
        selectedPackages: Set<String>,
    ): UsageIntervalTotals {
        require(windowStartMillis < windowEndMillis) { "Measurement window must have positive duration" }

        val ordered = events.sortedBy(UsageEventRecord::timestampMillis)
        var screenInteractive: Boolean? = null
        var initialScreenStateKnown: Boolean? = null
        var activeScreenOffStart: Long? = null
        var nonUseMillis = 0L
        val foregroundStarts = mutableMapOf<String, Long>()
        var distractingMillis = 0L

        fun closeForeground(packageName: String, at: Long) {
            val startedAt = foregroundStarts.remove(packageName) ?: return
            distractingMillis += (at.coerceAtMost(windowEndMillis) - startedAt.coerceAtLeast(windowStartMillis))
                .coerceAtLeast(0L)
        }

        for (event in ordered) {
            val at = event.timestampMillis
            if (at < windowStartMillis) {
                when (event.kind) {
                    UsageEventKind.SCREEN_ON -> {
                        screenInteractive = true
                        activeScreenOffStart = null
                    }
                    UsageEventKind.SCREEN_OFF -> {
                        screenInteractive = false
                        activeScreenOffStart = windowStartMillis
                        foregroundStarts.keys.toList().forEach { closeForeground(it, windowStartMillis) }
                    }
                    UsageEventKind.APP_FOREGROUND -> {
                        val pkg = event.packageName
                        if (pkg != null && pkg in selectedPackages && screenInteractive != false) {
                            foregroundStarts.keys.filter { it != pkg }.toList()
                                .forEach { closeForeground(it, windowStartMillis) }
                            foregroundStarts.putIfAbsent(pkg, at)
                        }
                    }
                    UsageEventKind.APP_BACKGROUND -> event.packageName?.let { closeForeground(it, windowStartMillis) }
                }
                continue
            }
            if (initialScreenStateKnown == null) {
                initialScreenStateKnown = screenInteractive != null ||
                    (at == windowStartMillis && (event.kind == UsageEventKind.SCREEN_ON || event.kind == UsageEventKind.SCREEN_OFF))
            }
            if (at >= windowEndMillis) break

            when (event.kind) {
                UsageEventKind.SCREEN_ON -> {
                    if (screenInteractive == false) {
                        activeScreenOffStart?.let { nonUseMillis += (at - it).coerceAtLeast(0L) }
                    }
                    screenInteractive = true
                    activeScreenOffStart = null
                }
                UsageEventKind.SCREEN_OFF -> {
                    if (screenInteractive != false) {
                        screenInteractive = false
                        activeScreenOffStart = at
                    }
                    foregroundStarts.keys.toList().forEach { closeForeground(it, at) }
                }
                UsageEventKind.APP_FOREGROUND -> {
                    val pkg = event.packageName
                    if (screenInteractive == true && pkg != null && pkg in selectedPackages) {
                        foregroundStarts.keys.filter { it != pkg }.toList().forEach { closeForeground(it, at) }
                        foregroundStarts.putIfAbsent(pkg, at)
                    }
                }
                UsageEventKind.APP_BACKGROUND -> event.packageName?.let { closeForeground(it, at) }
            }
        }

        if (initialScreenStateKnown == null) initialScreenStateKnown = screenInteractive != null
        if (screenInteractive == false) {
            activeScreenOffStart?.let { start ->
                nonUseMillis += (windowEndMillis - start.coerceAtLeast(windowStartMillis)).coerceAtLeast(0L)
            }
        }
        foregroundStarts.keys.toList().forEach { closeForeground(it, windowEndMillis) }

        return UsageIntervalTotals(
            nonUseMillis = nonUseMillis.coerceAtMost(windowEndMillis - windowStartMillis),
            distractingAppMillis = distractingMillis.coerceAtMost(windowEndMillis - windowStartMillis),
            initialScreenStateKnown = initialScreenStateKnown == true,
        )
    }
}
