package com.example.petdetox.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_stats")
data class DailyStatsEntity(
    @PrimaryKey val dateKey: String,
    val timezoneId: String,
    val nonUseMinutes: Int?,
    val distractionAppMinutes: Int?,
    val earnedXp: Int,
    val measurementStatus: String,
    val isFinalized: Boolean,
    val finalizedAtMillis: Long?,
    val lastMeasuredAtMillis: Long?,
)
