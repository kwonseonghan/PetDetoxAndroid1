package com.example.petdetox.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.petdetox.core.model.UserSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.userSettingsDataStore by preferencesDataStore(name = "user_settings")

class SettingsRepository(context: Context) {
    private val dataStore = context.applicationContext.userSettingsDataStore

    val settings: Flow<UserSettings> = dataStore.data.map { preferences ->
        UserSettings(
            dailyGoalMinutes = preferences[Keys.DAILY_GOAL] ?: 240,
            activeStartMinute = preferences[Keys.ACTIVE_START] ?: 8 * 60,
            activeEndMinute = preferences[Keys.ACTIVE_END] ?: 23 * 60,
            selectedAppPackages = preferences[Keys.SELECTED_APPS] ?: emptySet(),
            dailyAppLimitMinutes = preferences[Keys.APP_LIMIT] ?: 60,
            onboardingCompleted = preferences[Keys.ONBOARDING_COMPLETED] ?: false,
            petName = preferences[Keys.PET_NAME] ?: "새싹이",
            settingsVersion = preferences[Keys.SETTINGS_VERSION] ?: 1,
        )
    }

    suspend fun save(settings: UserSettings) {
        require(settings.dailyGoalMinutes in 1..1_440) { "Daily goal must be between 1 and 1440 minutes" }
        require(settings.activeStartMinute in 0..1_439) { "Invalid active start time" }
        require(settings.activeEndMinute in 1..1_440) { "Invalid active end time" }
        require(settings.activeStartMinute < settings.activeEndMinute) { "Active hours must end after they start; overnight windows are not supported" }
        require(settings.dailyAppLimitMinutes in 0..1_440) { "Invalid app usage limit" }
        require(settings.selectedAppPackages.none(String::isBlank)) { "App package names must not be blank" }

        dataStore.edit { preferences ->
            preferences[Keys.DAILY_GOAL] = settings.dailyGoalMinutes
            preferences[Keys.ACTIVE_START] = settings.activeStartMinute
            preferences[Keys.ACTIVE_END] = settings.activeEndMinute
            preferences[Keys.SELECTED_APPS] = settings.selectedAppPackages
            preferences[Keys.APP_LIMIT] = settings.dailyAppLimitMinutes
            preferences[Keys.ONBOARDING_COMPLETED] = settings.onboardingCompleted
            preferences[Keys.PET_NAME] = settings.petName
            preferences[Keys.SETTINGS_VERSION] = settings.settingsVersion
        }
    }

    private object Keys {
        val DAILY_GOAL = intPreferencesKey("daily_goal_minutes")
        val ACTIVE_START = intPreferencesKey("active_start_minute")
        val ACTIVE_END = intPreferencesKey("active_end_minute")
        val SELECTED_APPS = stringSetPreferencesKey("selected_app_packages")
        val APP_LIMIT = intPreferencesKey("daily_app_limit_minutes")
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
        val PET_NAME = stringPreferencesKey("pet_name")
        val SETTINGS_VERSION = intPreferencesKey("settings_version")
    }
}
