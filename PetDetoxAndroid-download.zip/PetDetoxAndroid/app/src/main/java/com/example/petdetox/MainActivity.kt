package com.example.petdetox

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.petdetox.feature.app.PetDetoxViewModel
import com.example.petdetox.navigation.PetDetoxRoot
import com.example.petdetox.platform.work.UsageRefreshScheduler
import com.example.petdetox.ui.theme.PetDetoxTheme

class MainActivity : ComponentActivity() {
    private val viewModel: PetDetoxViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        UsageRefreshScheduler.schedule(applicationContext)
        setContent { PetDetoxTheme { PetDetoxRoot(viewModel) } }
    }
}
