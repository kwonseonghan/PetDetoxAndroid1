package com.example.petdetox.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.petdetox.data.local.entity.PetStateEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PetStateDao {
    @Query("SELECT * FROM pet_state WHERE id = :id LIMIT 1")
    fun observeById(id: Int = PetStateEntity.SINGLE_PET_ID): Flow<PetStateEntity?>

    @Query("SELECT * FROM pet_state WHERE id = :id LIMIT 1")
    suspend fun getById(id: Int = PetStateEntity.SINGLE_PET_ID): PetStateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(state: PetStateEntity)

    @Query("UPDATE pet_state SET totalXp = totalXp + :delta, updatedAtMillis = :updatedAtMillis WHERE id = :id")
    suspend fun addXp(id: Int = PetStateEntity.SINGLE_PET_ID, delta: Long, updatedAtMillis: Long): Int
}
