package com.example.petdetox.platform.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.petdetox.data.repository.PetDetoxRepository
import kotlinx.coroutines.flow.first

/** Periodic best-effort refresh; WorkManager timing is not exact and may be deferred by Android. */
class UsageRefreshWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        return try {
            val repository = PetDetoxRepository(applicationContext)
            if (!repository.settings.first().onboardingCompleted) {
                Result.success()
            } else {
                repository.measureAndStoreUsage()
                Result.success()
            }
        } catch (_: Exception) {
            Result.retry()
        }
    }
}
