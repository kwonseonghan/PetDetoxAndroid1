package com.example.petdetox.domain.usage

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UsageEventReducerTest {
    private val start = 100_000L
    private val end = 700_000L

    @Test
    fun screenOffIntervalsAreClippedToConfiguredWindow() {
        val events = listOf(
            UsageEventRecord(80_000L, UsageEventKind.SCREEN_ON),
            UsageEventRecord(150_000L, UsageEventKind.SCREEN_OFF),
            UsageEventRecord(350_000L, UsageEventKind.SCREEN_ON),
            UsageEventRecord(500_000L, UsageEventKind.SCREEN_OFF),
        )
        val result = UsageEventReducer.reduce(events, start, end, emptySet())
        assertTrue(result.initialScreenStateKnown)
        assertEquals(400_000L, result.nonUseMillis)
    }

    @Test
    fun selectedAppUsageCountsOnlyWhileScreenInteractiveAndWithinWindow() {
        val events = listOf(
            UsageEventRecord(80_000L, UsageEventKind.SCREEN_ON),
            UsageEventRecord(120_000L, UsageEventKind.APP_FOREGROUND, "video.app"),
            UsageEventRecord(220_000L, UsageEventKind.APP_BACKGROUND, "video.app"),
            UsageEventRecord(300_000L, UsageEventKind.APP_FOREGROUND, "video.app"),
            UsageEventRecord(400_000L, UsageEventKind.SCREEN_OFF),
            UsageEventRecord(500_000L, UsageEventKind.APP_BACKGROUND, "video.app"),
        )
        val result = UsageEventReducer.reduce(events, start, end, setOf("video.app"))
        assertEquals(200_000L, result.distractingAppMillis)
    }

    @Test
    fun unknownInitialScreenStateIsReported() {
        val events = listOf(UsageEventRecord(150_000L, UsageEventKind.SCREEN_OFF))
        val result = UsageEventReducer.reduce(events, start, end, emptySet())
        assertFalse(result.initialScreenStateKnown)
    }

    @Test
    fun screenAlreadyOffAtWindowStartCountsFromBoundary() {
        val events = listOf(
            UsageEventRecord(80_000L, UsageEventKind.SCREEN_OFF),
            UsageEventRecord(400_000L, UsageEventKind.SCREEN_ON),
        )
        val result = UsageEventReducer.reduce(events, start, end, emptySet())
        assertTrue(result.initialScreenStateKnown)
        assertEquals(300_000L, result.nonUseMillis)
    }
}
