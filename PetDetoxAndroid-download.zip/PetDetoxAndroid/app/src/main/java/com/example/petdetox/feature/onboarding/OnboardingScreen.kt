package com.example.petdetox.feature.onboarding

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.petdetox.core.ui.components.PetIllustration
import com.example.petdetox.core.ui.components.PrimaryButton
import com.example.petdetox.core.ui.components.SectionCard

@Composable
fun OnboardingScreen(
    goalMinutes: Float,
    onGoalChange: (Float) -> Unit,
    onContinue: () -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        Text("작은 휴식이 모이면", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("펫도 자라나요", fontSize = 30.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        PetIllustration(size = 190.dp)
        Text(
            "휴대폰을 내려놓는 시간을 모아\n나만의 작은 친구를 키워 보세요.",
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        SectionCard {
            Text("하루 디톡스 목표", style = MaterialTheme.typography.titleMedium)
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                Text("${goalMinutes.toInt()}", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("분", modifier = Modifier.padding(start = 5.dp, bottom = 5.dp), style = MaterialTheme.typography.titleMedium)
            }
            Slider(value = goalMinutes, onValueChange = onGoalChange, valueRange = 60f..480f, steps = 13)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("1시간", style = MaterialTheme.typography.labelSmall)
                Text("8시간", style = MaterialTheme.typography.labelSmall)
            }
        }
        Column(modifier = Modifier.weight(1f, fill = false), verticalArrangement = Arrangement.Bottom) {
            PrimaryButton(text = "목표 설정하기", onClick = onContinue)
        }
    }
}
