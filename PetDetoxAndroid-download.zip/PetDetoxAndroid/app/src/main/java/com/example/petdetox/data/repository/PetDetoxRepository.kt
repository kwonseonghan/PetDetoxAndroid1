package com.example.petdetox.data.repository

import android.content.Context
import androidx.room.withTransaction
import com.example.petdetox.core.model.UserSettings
import com.example.petdetox.data.local.AppDatabase
import com.example.petdetox.data.local.entity.DailyStatsEntity
import com.example.petdetox.data.local.entity.PetStateEntity
import com.example.petdetox.data.local.entity.UsageSnapshotEntity
import com.example.petdetox.data.preferences.SettingsRepository
import com.example.petdetox.platform.usage.UsageMeasurementResult
import com.example.petdetox.platform.usage.UsageMeasurementService
import com.example.petdetox.domain.growth.GrowthCalculation
import com.example.petdetox.domain.growth.GrowthCalculator
import com.example.petdetox.domain.growth.GrowthInput
import com.example.petdetox.domain.growth.MeasurementStatus as GrowthMeasurementStatus
import com.example.petdetox.domain.growth.PetProgression
import java.time.ZoneId
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.time.LocalDate

/** Thin local repository. XP settlement and usage collection are separate domain/platform units. */
class PetDetoxRepository(context: Context) {
    private val database = AppDatabase.getInstance(context)
    private val petDao = database.petStateDao()
    private val dailyStatsDao = database.dailyStatsDao()
    private val usageSnapshotDao = database.usageSnapshotDao()
    private val settingsRepository = SettingsRepository(context)
    private val usageMeasurementService = UsageMeasurementService(context)

    val settings: Flow<UserSettings> = settingsRepository.settings
    val petState: Flow<PetStateEntity?> = petDao.observeById()
    val recentDailyStats: Flow<List<DailyStatsEntity>> = dailyStatsDao.observeRecentSevenDays()
    val latestUsageSnapshot: Flow<UsageSnapshotEntity?> = usageSnapshotDao.observeLatest()

    suspend fun saveSettings(settings: UserSettings) = settingsRepository.save(settings)

    suspend fun ensurePetExists(nowMillis: Long = System.currentTimeMillis()) {
        if (petDao.getById() == null) {
            petDao.upsert(
                PetStateEntity(
                    createdAtMillis = nowMillis,
                    updatedAtMillis = nowMillis,
                ),
            )
        }
    }

    suspend fun saveDailyStats(stats: DailyStatsEntity) = dailyStatsDao.upsert(stats)

    /** Atomically finalizes one local day. The primary-key row and isFinalized flag prevent double XP. */
    suspend fun finalizeDayIfEligible(date: LocalDate, measuredAtMillis: Long): Int = database.withTransaction {
        val dateKey = date.toString()
        val existing = dailyStatsDao.getByDate(dateKey)
        if (existing?.isFinalized == true) return@withTransaction existing.earnedXp
        val settings = settingsRepository.settings.first()
        val periodStart = date.atStartOfDay(ZoneId.systemDefault())
            .plusMinutes(settings.activeStartMinute.toLong()).toInstant().toEpochMilli()
        val snapshot = usageSnapshotDao.getLatestForPeriod(periodStart) ?: return@withTransaction 0
        if (snapshot.measurementStatus != com.example.petdetox.platform.usage.MeasurementStatus.COMPLETE.name ||
            snapshot.nonUseMinutes == null || snapshot.distractionAppMinutes == null
        ) return@withTransaction 0

        val calculation = GrowthCalculator.calculate(
            GrowthInput(
                dailyGoalMinutes = settings.dailyGoalMinutes,
                nonUseMinutes = snapshot.nonUseMinutes,
                distractionAppMinutes = snapshot.distractionAppMinutes,
                dailyAppLimitMinutes = settings.dailyAppLimitMinutes,
                measurementStatus = GrowthMeasurementStatus.COMPLETE,
            ),
        )
        val earnedXp = (calculation as? GrowthCalculation.Success)?.earnedXp ?: return@withTransaction 0
        val currentPet = petDao.getById() ?: PetStateEntity(createdAtMillis = measuredAtMillis, updatedAtMillis = measuredAtMillis)
        val newTotalXp = currentPet.totalXp + earnedXp
        val newStage = PetProgression.stageFor(newTotalXp).name
        petDao.upsert(currentPet.copy(
            totalXp = newTotalXp,
            level = (newTotalXp / 100L + 1L).coerceAtMost(Int.MAX_VALUE.toLong()).toInt(),
            evolutionStage = newStage,
            updatedAtMillis = measuredAtMillis,
        ))
        dailyStatsDao.upsert(
            DailyStatsEntity(
                dateKey = dateKey,
                timezoneId = ZoneId.systemDefault().id,
                nonUseMinutes = snapshot.nonUseMinutes,
                distractionAppMinutes = snapshot.distractionAppMinutes,
                earnedXp = earnedXp,
                measurementStatus = snapshot.measurementStatus,
                isFinalized = true,
                finalizedAtMillis = measuredAtMillis,
                lastMeasuredAtMillis = snapshot.measuredAtMillis,
            ),
        )
        earnedXp
    }

    suspend fun getDailyStats(dateKey: String): DailyStatsEntity? = dailyStatsDao.getByDate(dateKey)

    suspend fun saveUsageSnapshot(snapshot: UsageSnapshotEntity): Long = usageSnapshotDao.insert(snapshot)

    /** Measures locally, then stores only aggregate minutes and measurement status. */
    suspend fun measureAndStoreUsage(
        date: LocalDate = LocalDate.now(),
        nowMillis: Long = System.currentTimeMillis(),
    ): UsageMeasurementResult {
        val result = usageMeasurementService.measure(settingsRepository.settings.first(), date, nowMillis)
        saveUsageSnapshot(result.toEntity())
        trimUsageSnapshots(nowMillis - 14L * 24L * 60L * 60L * 1000L)
        if (result.status == com.example.petdetox.platform.usage.MeasurementStatus.COMPLETE) {
            ensurePetExists(nowMillis)
            finalizeDayIfEligible(date, nowMillis)
        }
        return result
    }

    suspend fun trimUsageSnapshots(retainAfterMillis: Long): Int =
        usageSnapshotDao.deleteOlderThan(retainAfterMillis)
}
