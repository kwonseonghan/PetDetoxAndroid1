package com.example.petdetox.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.petdetox.data.local.entity.DailyStatsEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DailyStatsDao {
    @Query("SELECT * FROM daily_stats ORDER BY dateKey DESC LIMIT 7")
    fun observeRecentSevenDays(): Flow<List<DailyStatsEntity>>

    @Query("SELECT * FROM daily_stats WHERE dateKey = :dateKey LIMIT 1")
    suspend fun getByDate(dateKey: String): DailyStatsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(stats: DailyStatsEntity)

    @Query("SELECT * FROM daily_stats WHERE dateKey BETWEEN :startDate AND :endDate ORDER BY dateKey ASC")
    suspend fun getRange(startDate: String, endDate: String): List<DailyStatsEntity>
}
