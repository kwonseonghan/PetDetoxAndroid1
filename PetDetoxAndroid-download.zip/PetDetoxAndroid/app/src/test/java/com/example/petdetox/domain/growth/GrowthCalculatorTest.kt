package com.example.petdetox.domain.growth

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GrowthCalculatorTest {
    @Test
    fun completeMeasurementCalculatesExpectedXp() {
        val result = GrowthCalculator.calculate(
            GrowthInput(240, 120, 30, 60, MeasurementStatus.COMPLETE),
        ) as GrowthCalculation.Success

        assertEquals(13, result.earnedXp)
        assertEquals(0.5, result.nonUseRatio, 0.0001)
        assertEquals(0.75, result.goalMultiplier, 0.0001)
        assertEquals(0.75, result.distractionMultiplier, 0.0001)
    }

    @Test
    fun incompleteMeasurementNeverAwardsXp() {
        val result = GrowthCalculator.calculate(
            GrowthInput(240, null, null, 60, MeasurementStatus.UNAVAILABLE),
        )
        assertEquals(
            GrowthCalculation.NotCalculated(GrowthFailureReason.MEASUREMENT_NOT_COMPLETE),
            result,
        )
    }

    @Test
    fun zeroAppLimitHasExplicitBehavior() {
        val noUse = GrowthCalculator.calculate(
            GrowthInput(240, 60, 0, 0, MeasurementStatus.COMPLETE),
        ) as GrowthCalculation.Success
        val someUse = GrowthCalculator.calculate(
            GrowthInput(240, 60, 1, 0, MeasurementStatus.COMPLETE),
        ) as GrowthCalculation.Success

        assertEquals(1.0, noUse.distractionMultiplier, 0.0001)
        assertEquals(0.5, someUse.distractionMultiplier, 0.0001)
    }

    @Test
    fun invalidInputIsRejected() {
        val result = GrowthCalculator.calculate(
            GrowthInput(0, 60, 0, 60, MeasurementStatus.COMPLETE),
        )
        assertEquals(GrowthCalculation.NotCalculated(GrowthFailureReason.INVALID_DAILY_GOAL), result)
    }

    @Test
    fun evolutionThresholdsAreInclusive() {
        assertEquals(EvolutionStage.EGG, PetProgression.stageFor(0))
        assertEquals(EvolutionStage.EGG, PetProgression.stageFor(99))
        assertEquals(EvolutionStage.BABY, PetProgression.stageFor(100))
        assertEquals(EvolutionStage.GROWING, PetProgression.stageFor(300))
        assertEquals(EvolutionStage.ADULT, PetProgression.stageFor(700))
    }

    @Test
    fun progressResetsAtEvolutionAndStopsAtAdult() {
        val atBaby = PetProgression.progressFor(100)
        assertEquals(200, atBaby.xpUntilNextStage)
        assertEquals(0f, atBaby.progressToNextStage, 0.0001f)

        val adult = PetProgression.progressFor(700)
        assertEquals(null, adult.nextStageThresholdXp)
        assertEquals(0, adult.xpUntilNextStage)
        assertTrue(adult.progressToNextStage == 1f)
    }
}
