package com.example.petdetox.navigation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.example.petdetox.feature.app.PetDetoxViewModel
import com.example.petdetox.feature.home.HomeScreen
import com.example.petdetox.feature.onboarding.OnboardingScreen
import com.example.petdetox.feature.settings.SettingsScreen
import com.example.petdetox.feature.statistics.StatisticsScreen
import com.example.petdetox.platform.permissions.UsageAccessPermission
import androidx.compose.ui.platform.LocalContext

private enum class MainTab(val label: String) { HOME("홈"), STATISTICS("통계"), SETTINGS("설정") }

@Composable
fun PetDetoxRoot(viewModel: PetDetoxViewModel) {
    val settings by viewModel.settings.collectAsState()
    val pet by viewModel.petState.collectAsState()
    val stats by viewModel.recentDailyStats.collectAsState()
    val snapshot by viewModel.latestUsageSnapshot.collectAsState()
    val message by viewModel.message.collectAsState()
    val measuring by viewModel.isMeasuring.collectAsState()
    val apps by viewModel.installedApps.collectAsState()
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    val context = LocalContext.current

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        if (settings.onboardingCompleted && UsageAccessPermission.isGranted(context)) viewModel.refreshMeasurement()
    }
    LaunchedEffect(settings.onboardingCompleted) {
        if (settings.onboardingCompleted && UsageAccessPermission.isGranted(context)) viewModel.refreshMeasurement()
    }

    var onboardingGoal by rememberSaveable(settings.dailyGoalMinutes) { androidx.compose.runtime.mutableFloatStateOf(settings.dailyGoalMinutes.toFloat()) }
    if (!settings.onboardingCompleted) {
        OnboardingScreen(
            goalMinutes = onboardingGoal,
            onGoalChange = { onboardingGoal = it },
            onContinue = { viewModel.completeOnboarding(onboardingGoal.toInt()) },
        )
        return
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                MainTab.entries.forEachIndexed { index, tab ->
                    val icon = when (tab) {
                        MainTab.HOME -> Icons.Outlined.Home
                        MainTab.STATISTICS -> Icons.Outlined.BarChart
                        MainTab.SETTINGS -> Icons.Outlined.Settings
                    }
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = { Icon(imageVector = icon, contentDescription = tab.label) },
                        label = { Text(tab.label) },
                    )
                }
            }
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(innerPadding)
                .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 22.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (message != null) {
                androidx.compose.material3.Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = MaterialTheme.shapes.large,
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(message ?: "", style = MaterialTheme.typography.bodyMedium)
                        TextButton(onClick = viewModel::dismissMessage) { Text("확인") }
                    }
                }
            }
            when (MainTab.entries.getOrNull(selectedTab) ?: MainTab.HOME) {
                MainTab.HOME -> HomeScreen(
                    settings = settings,
                    pet = pet,
                    snapshot = snapshot,
                    isMeasuring = measuring,
                    onRefresh = viewModel::refreshMeasurement,
                )
                MainTab.STATISTICS -> StatisticsScreen(stats, settings.dailyGoalMinutes)
                MainTab.SETTINGS -> SettingsScreen(
                    settings = settings,
                    apps = apps,
                    onGoalChange = viewModel::updateGoal,
                    onAppLimitChange = viewModel::updateAppLimit,
                    onToggleApp = viewModel::toggleApp,
                    onPetNameChange = viewModel::updatePetName,
                )
            }
        }
    }
}
