package com.example.petdetox.ui.theme

import androidx.compose.ui.graphics.Color

val Sage = Color(0xFF718C69)
val SageDark = Color(0xFF42583D)
val WarmPaper = Color(0xFFF7F5EE)
val Ink = Color(0xFF2E302B)
val MutedInk = Color(0xFF6D7168)
val SoftPeach = Color(0xFFE9B7A5)
val Butter = Color(0xFFE9D68C)
