package com.example.petdetox.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Aggregated measurements only; raw UsageEvents are not persisted. */
@Entity(tableName = "usage_snapshots")
data class UsageSnapshotEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val periodStartMillis: Long,
    val periodEndMillis: Long,
    val measuredAtMillis: Long,
    val measurementStatus: String,
    val nonUseMinutes: Int?,
    val distractionAppMinutes: Int?,
)
