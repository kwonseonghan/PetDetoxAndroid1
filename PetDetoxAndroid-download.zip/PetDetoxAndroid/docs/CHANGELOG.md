# 작업 기록

## 2026-10-25 — 작업 1: 프로젝트 초기 설정

### 변경 파일
- `settings.gradle.kts`: app 모듈 및 저장소 설정
- `build.gradle.kts`: Android Gradle Plugin/Kotlin 플러그인 버전 지정
- `gradle.properties`: AndroidX 및 Kotlin 기본 설정
- `app/build.gradle.kts`: SDK, Compose 및 테스트 의존성 설정
- `app/src/main/AndroidManifest.xml`: 앱 진입점과 최소 애플리케이션 메타데이터
- `app/src/main/res/values/styles.xml`: 시스템 바와 기본 Android 테마
- `app/src/main/java/com/example/petdetox/MainActivity.kt`: Compose 앱 진입점 및 임시 실행 확인 화면
- `app/src/main/java/com/example/petdetox/ui/theme/Color.kt`: 초기 색상 토큰
- `app/src/main/java/com/example/petdetox/ui/theme/Theme.kt`: Material 3 테마
- `README.md`: 환경 설정과 실행 안내

### 변경 이유
기존 프로젝트가 제공되지 않아 기존 코드에 영향을 주지 않는 새 Android Studio 프로젝트 뼈대를 생성했습니다. 실제 제품 UI와 기능은 이번 작업 범위에 포함하지 않았습니다.

### 테스트 결과
- 파일 구조 및 필수 파일 존재 확인: 수행 예정
- Gradle 빌드 / Android 기기 실행: 미실행 (환경에 Gradle 및 Android SDK 없음)

### 알려진 제약
- `com.example.petdetox`는 임시 application ID이며 출시 전 고유 ID로 변경해야 합니다.
- Gradle Wrapper는 아직 포함하지 않았습니다. Android Studio의 Gradle import/sync를 통해 실행 환경을 구성합니다.

## 2026-10-25 — 작업 2: 공통 컴포넌트 및 화면 구조

### 변경 파일
- `app/build.gradle.kts`: Material Icons 의존성 추가
- `MainActivity.kt`: 루트 화면 진입으로 변경
- `navigation/PetDetoxRoot.kt`: 첫 실행 흐름과 하단 탭 구성
- `core/ui/components/PetIllustration.kt`: 교체 가능한 임시 벡터 마스코트
- `core/ui/components/CommonComponents.kt`: 카드, 버튼, 경험치 바, 통계 값, 설정 행
- `feature/onboarding/OnboardingScreen.kt`: 하루 목표 설정 UI
- `feature/home/HomeScreen.kt`: 펫·경험치·오늘의 휴식 홈 화면 구조
- `feature/statistics/StatisticsScreen.kt`: 최근 7일 통계 빈 상태 UI
- `feature/settings/SettingsScreen.kt`: 목표·방해 앱·권한·데이터 설정 UI

### 변경 이유
확정한 UI/UX에 맞춰 화면 구조와 재사용 컴포넌트를 먼저 만들었습니다. 실제 측정·저장 기능은 다음 작업 단위에서 연결합니다.

### 테스트 결과
- 정적 구조 검사: 실행 예정
- Gradle 빌드 및 Compose UI 테스트: 환경 제약으로 미실행

### 알려진 제약
- 목표값과 온보딩 완료 상태는 현재 앱 메모리/화면 상태에만 존재하며 재실행 후 유지되지 않습니다.
- 펫 경험치와 통계는 UI 확인용 임시 값입니다.
- 마스코트는 임시 Compose 벡터이며, 확정 캐릭터 에셋으로 교체해야 합니다.
- 설정 행은 현재 시각적 구조만 구현되어 있고 상호작용은 미연결입니다.

## 2026-10-25 — 작업 3: 성장 계산 도메인 로직

### 변경 파일
- `domain/growth/GrowthCalculator.kt`: 측정 유효성 검사 및 확정 XP 공식
- `domain/growth/PetProgression.kt`: 0/100/300/700 XP 진화 단계 계산
- `app/src/test/.../GrowthCalculatorTest.kt`: XP·측정 실패·0 한도·진화 임계값 테스트

### 변경 이유
UI와 분리된 결정적 성장 계산기를 구현해 측정 실패 시 경험치를 지급하지 않고, XP 중복 지급 방지 계층과 연결할 수 있는 기반을 마련했습니다.

### 테스트 결과
- JUnit 테스트 소스 작성
- 아래 기록된 로컬 Kotlin 컴파일 및 독립 스모크 테스트 실행 결과 참조

### 알려진 제약
- 일일 정산 및 Room 트랜잭션은 아직 구현하지 않았습니다.
- Android UsageStatsManager에서 실제 측정값을 가져오는 기능은 아직 연결되지 않았습니다.

## 2026-10-25 — 작업 4: 로컬 데이터 저장 계층

### 변경 파일
- `build.gradle.kts`, `app/build.gradle.kts`: KSP, Room, DataStore 의존성 추가
- `core/model/UserSettings.kt`: 설정 모델 및 기본값
- `data/local/entity/`: 펫 상태, 일별 통계, 집계 측정 스냅샷 엔티티
- `data/local/dao/`: 엔티티별 DAO
- `data/local/AppDatabase.kt`: Room 데이터베이스 싱글턴
- `data/preferences/SettingsRepository.kt`: DataStore 설정 읽기·검증·저장
- `data/repository/PetDetoxRepository.kt`: 화면과 로컬 저장소 사이의 얇은 저장소 계층

### 변경 이유
기획대로 설정은 DataStore, 날짜별 기록과 펫 상태는 Room에 분리했습니다. 원시 사용 이벤트 대신 집계된 측정 스냅샷만 저장하도록 구성했습니다.

### 테스트 결과
- 파일 및 코드 구조 검사: 실행 예정
- Android 빌드/Room 코드 생성/기기 저장 테스트: 환경 제약으로 미실행

### 알려진 제약
- 화면은 아직 새 Repository와 연결되지 않았습니다.
- 일일 정산 트랜잭션과 경험치 지급 중복 방지 로직은 다음 단계에서 구현합니다.
- Room 스키마 마이그레이션은 아직 첫 스키마라 미작성입니다.

## 2026-10-25 — 작업 5: 사용 기록 측정 기반

### 변경 파일
- `app/build.gradle.kts`: 화면 상태 이벤트를 지원하는 최소 버전을 Android 9(API 28)로 상향
- `app/src/main/AndroidManifest.xml`: `PACKAGE_USAGE_STATS` 선언
- `platform/permissions/UsageAccessPermission.kt`: 사용정보 접근 권한 확인 및 시스템 설정 열기
- `platform/usage/UsageMeasurementService.kt`: `UsageStatsManager.queryEvents` 조회, 활성 시간 계산, COMPLETE/PARTIAL/UNAVAILABLE 및 원인 분류
- `domain/usage/UsageEventReducer.kt`: 화면 꺼짐 구간 및 선택 앱 전경 사용 시간 집계, 측정 구간 경계 처리
- `data/repository/PetDetoxRepository.kt`: 측정 결과를 집계 스냅샷으로 로컬 저장
- `data/preferences/SettingsRepository.kt`: 같은 날의 활성 시간만 허용하도록 설정 검증
- `core/ui/components/CommonComponents.kt`, `feature/settings/SettingsScreen.kt`: 사용 기록 권한 설정으로 이동하고 복귀 후 상태 갱신
- `app/src/test/java/com/example/petdetox/domain/usage/UsageEventReducerTest.kt`: 집계 로직 단위 테스트 소스
- `README.md`: 권한 승인 절차, 측정 제한 및 현재 연결 범위 문서화

### 변경 이유
Android 9(API 28)부터 제공되는 `SCREEN_INTERACTIVE` / `SCREEN_NON_INTERACTIVE` 이벤트를 활용해 실제 화면 비상호작용 구간을 계산합니다. 원시 이벤트는 저장하지 않고 분 단위 집계와 상태만 Room에 기록합니다.

### 테스트 결과
- 독립 Kotlin 컴파일 및 스모크 테스트: **PASS — 사용 기록 집계 6개 assertion**
- Manifest XML 파싱: **PASS**; ZIP 무결성 검사: **PASS**
- Android Gradle 빌드, KSP/Room 코드 생성, 기기별 `UsageStatsManager` 동작: 미실행 (이 환경에 Android SDK와 Gradle 실행 파일 없음)

### 알려진 제약
- 화면 및 설정 UI 전체는 아직 Repository에 연결되지 않았으며, 방해 앱 선택 UI와 자동 주기 측정(WorkManager)은 다음 작업입니다.
- `measureAndStoreUsage()`는 호출 시점에 측정하고 스냅샷을 저장합니다. 자동 호출/일일 경험치 정산은 아직 연결하지 않았습니다.
- 초기 화면 상태를 추론할 수 없거나 권한/이벤트가 부족하면 측정값을 확정하지 않습니다. 제조사별 UsageStats 차이로 실제 기기 검증이 필요합니다.
- 활성 시간은 자정을 넘지 않는 같은 날 구간만 지원합니다.

## 2026-10-25 — 작업 6: 로컬 데이터 및 실제 화면 연결

### 변경 파일
- `feature/app/PetDetoxViewModel.kt`: 설정/펫/기록 상태 수집, 설정 저장, 사용 기록 갱신, 런처 앱 목록 로딩
- `MainActivity.kt`, `navigation/PetDetoxRoot.kt`: ViewModel 연결, 영구 온보딩, 화면 복귀 시 권한이 있을 때 재측정
- `feature/home/HomeScreen.kt`: 임시 XP/시간 제거, Room 기반 펫 성장·측정값 표시, 수동 측정 버튼
- `feature/settings/SettingsScreen.kt`: 목표/펫 이름/방해 앱/사용 한도 설정을 실제 저장소에 연결
- `feature/statistics/StatisticsScreen.kt`: 확정된 일별 기록으로 7일 그래프 및 요약 표시
- `data/repository/PetDetoxRepository.kt`, `data/local/dao/UsageSnapshotDao.kt`: 측정 완료 시 원자적 일일 XP 정산, 날짜당 중복 지급 방지, 오래된 스냅샷 정리
- `platform/work/UsageRefreshWorker.kt`, `UsageRefreshScheduler.kt`: 15분 주기의 best-effort 백그라운드 측정
- `AndroidManifest.xml`: 런처 앱 검색을 위한 package visibility 쿼리
- `app/build.gradle.kts`: ViewModel 및 WorkManager 의존성

### 변경 이유
화면의 임시 수치를 제거하고 온보딩, 설정, 측정, 펫 성장, 통계가 로컬 저장 데이터로 연결되도록 했습니다. 측정이 COMPLETE일 때만 정산하며 Room 트랜잭션과 일별 기본키/확정 플래그로 중복 지급을 방지합니다. Android 백그라운드 작업은 정확한 실행 시각이 보장되지 않으므로 주기 작업은 보조 수단이고, 앱을 열 때도 측정을 갱신합니다.

### 테스트 결과
- 순수 Kotlin 독립 컴파일 및 스모크 테스트: **PASS — 사용 기록/성장 로직 7개 assertion**
- Manifest XML 파싱 및 필수 파일 검사: **PASS**
- 이번 통합 변경의 Android 빌드/Room KSP 코드 생성/실기기 테스트: 미실행 (환경에 Gradle, Android SDK가 없고 외부 다운로드도 DNS 단계에서 실패)

### 알려진 제약
- 아직 설치 가능한 APK를 생성하지 못했습니다. Android Studio에서 Gradle sync/build 후 기기 테스트가 필요합니다.
- UsageStats 이벤트의 제조사별 차이와 앱 강제 종료/절전 정책은 실기기 검증이 필요합니다.
- 주기 작업은 Android가 지연할 수 있습니다. 앱이 삭제되거나 사용 기록 권한이 해제되면 측정/정산이 보장되지 않습니다.
- 캐릭터 그림은 교체 가능한 임시 벡터입니다.
