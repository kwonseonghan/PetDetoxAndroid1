package com.example.petdetox.core.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.petdetox.ui.theme.Ink
import com.example.petdetox.ui.theme.Sage
import com.example.petdetox.ui.theme.SoftPeach

/** Temporary, replaceable vector mascot until the final character art is approved. */
@Composable
fun PetIllustration(
    modifier: Modifier = Modifier,
    size: Dp = 180.dp,
    bodyColor: Color = Sage,
) {
    Box(modifier = modifier.size(size)) {
        Canvas(modifier = Modifier.size(size)) {
            val w = this.size.width
            val h = this.size.height
            val center = Offset(w * 0.5f, h * 0.59f)

            // Soft, slightly squat body silhouette.
            drawOval(
                color = bodyColor,
                topLeft = Offset(w * 0.16f, h * 0.28f),
                size = Size(w * 0.68f, h * 0.61f),
            )
            // Two leaves growing from the head.
            val leftLeaf = Path().apply {
                moveTo(w * 0.48f, h * 0.33f)
                quadraticTo(w * 0.22f, h * 0.18f, w * 0.34f, h * 0.08f)
                quadraticTo(w * 0.48f, h * 0.10f, w * 0.52f, h * 0.29f)
                close()
            }
            val rightLeaf = Path().apply {
                moveTo(w * 0.51f, h * 0.31f)
                quadraticTo(w * 0.57f, h * 0.08f, w * 0.76f, h * 0.13f)
                quadraticTo(w * 0.78f, h * 0.28f, w * 0.55f, h * 0.35f)
                close()
            }
            drawPath(leftLeaf, color = Color(0xFF9DB58B))
            drawPath(rightLeaf, color = Color(0xFFB6C99A))

            // Small eyes, warm cheeks, and a quiet smile.
            drawCircle(color = Ink, radius = w * 0.025f, center = Offset(w * 0.39f, h * 0.55f))
            drawCircle(color = Ink, radius = w * 0.025f, center = Offset(w * 0.61f, h * 0.55f))
            drawCircle(color = SoftPeach.copy(alpha = 0.85f), radius = w * 0.045f, center = Offset(w * 0.30f, h * 0.62f))
            drawCircle(color = SoftPeach.copy(alpha = 0.85f), radius = w * 0.045f, center = Offset(w * 0.70f, h * 0.62f))
            val smile = Path().apply {
                moveTo(w * 0.45f, h * 0.64f)
                quadraticTo(w * 0.50f, h * 0.70f, w * 0.55f, h * 0.64f)
            }
            drawPath(
                path = smile,
                color = Ink,
                style = Stroke(width = w * 0.012f, cap = StrokeCap.Round),
            )
        }
    }
}
