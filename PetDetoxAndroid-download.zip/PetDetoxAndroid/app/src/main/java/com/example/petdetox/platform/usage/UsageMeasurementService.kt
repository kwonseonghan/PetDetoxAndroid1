package com.example.petdetox.platform.usage

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import com.example.petdetox.core.model.UserSettings
import com.example.petdetox.data.local.entity.UsageSnapshotEntity
import com.example.petdetox.domain.usage.UsageEventKind
import com.example.petdetox.domain.usage.UsageEventRecord
import com.example.petdetox.domain.usage.UsageEventReducer
import com.example.petdetox.platform.permissions.UsageAccessPermission
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.ZoneId

/** Measurement completeness is explicit: PARTIAL data must never be used for XP settlement. */
enum class MeasurementStatus { COMPLETE, PARTIAL, UNAVAILABLE }

enum class MeasurementIssue {
    NONE,
    USAGE_ACCESS_NOT_GRANTED,
    INVALID_ACTIVE_WINDOW,
    WINDOW_NOT_STARTED,
    SYSTEM_RETURNED_NO_EVENTS,
    INITIAL_SCREEN_STATE_UNKNOWN,
    QUERY_FAILED,
}

data class UsageMeasurementResult(
    val periodStartMillis: Long,
    val periodEndMillis: Long,
    val measuredAtMillis: Long,
    val status: MeasurementStatus,
    val issue: MeasurementIssue,
    val nonUseMinutes: Int?,
    val distractingAppMinutes: Int?,
) {
    fun toEntity() = UsageSnapshotEntity(
        periodStartMillis = periodStartMillis,
        periodEndMillis = periodEndMillis,
        measuredAtMillis = measuredAtMillis,
        measurementStatus = status.name,
        nonUseMinutes = nonUseMinutes,
        distractionAppMinutes = distractingAppMinutes,
    )
}

/**
 * Aggregates UsageStatsManager events locally. Raw event records are held in memory only and never
 * persisted. Call from any coroutine; querying and reducing run on Dispatchers.IO.
 */
class UsageMeasurementService(context: Context) {
    private val appContext = context.applicationContext

    suspend fun measure(
        settings: UserSettings,
        date: LocalDate = LocalDate.now(),
        nowMillis: Long = System.currentTimeMillis(),
    ): UsageMeasurementResult = withContext(Dispatchers.IO) {
        val zone = ZoneId.systemDefault()
        val windowStart = date.atStartOfDay(zone).plusMinutes(settings.activeStartMinute.toLong())
            .toInstant().toEpochMilli()
        val windowEnd = date.atStartOfDay(zone).plusMinutes(settings.activeEndMinute.toLong())
            .toInstant().toEpochMilli()

        fun result(
            status: MeasurementStatus,
            issue: MeasurementIssue,
            nonUse: Int? = null,
            distraction: Int? = null,
        ) = UsageMeasurementResult(windowStart, windowEnd, nowMillis, status, issue, nonUse, distraction)

        if (settings.activeStartMinute !in 0..1439 || settings.activeEndMinute !in 1..1440 ||
            settings.activeStartMinute >= settings.activeEndMinute
        ) return@withContext result(MeasurementStatus.UNAVAILABLE, MeasurementIssue.INVALID_ACTIVE_WINDOW)

        val observedEnd = minOf(nowMillis, windowEnd)
        if (observedEnd <= windowStart) {
            return@withContext result(MeasurementStatus.PARTIAL, MeasurementIssue.WINDOW_NOT_STARTED)
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            return@withContext result(MeasurementStatus.UNAVAILABLE, MeasurementIssue.QUERY_FAILED)
        }
        if (!UsageAccessPermission.isGranted(appContext)) {
            return@withContext result(MeasurementStatus.UNAVAILABLE, MeasurementIssue.USAGE_ACCESS_NOT_GRANTED)
        }

        try {
            val manager = appContext.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            // Earlier events let us infer whether the screen was already off at the start boundary.
            // Android retains UsageEvents for only a limited recent period, so old dates may be partial.
            val queryStart = (windowStart - 24L * 60L * 60L * 1000L).coerceAtLeast(0L)
            val usageEvents = manager.queryEvents(queryStart, observedEnd)
                ?: return@withContext result(MeasurementStatus.UNAVAILABLE, MeasurementIssue.SYSTEM_RETURNED_NO_EVENTS)

            val records = mutableListOf<UsageEventRecord>()
            val event = UsageEvents.Event()
            while (usageEvents.hasNextEvent()) {
                usageEvents.getNextEvent(event)
                val kind = when (event.eventType) {
                    UsageEvents.Event.SCREEN_INTERACTIVE -> UsageEventKind.SCREEN_ON
                    UsageEvents.Event.SCREEN_NON_INTERACTIVE -> UsageEventKind.SCREEN_OFF
                    UsageEvents.Event.ACTIVITY_RESUMED,
                    UsageEvents.Event.MOVE_TO_FOREGROUND -> UsageEventKind.APP_FOREGROUND
                    UsageEvents.Event.ACTIVITY_PAUSED,
                    UsageEvents.Event.ACTIVITY_STOPPED,
                    UsageEvents.Event.MOVE_TO_BACKGROUND -> UsageEventKind.APP_BACKGROUND
                    else -> null
                } ?: continue
                records += UsageEventRecord(
                    timestampMillis = event.timeStamp,
                    kind = kind,
                    packageName = event.packageName,
                )
            }

            if (records.isEmpty()) {
                return@withContext result(MeasurementStatus.PARTIAL, MeasurementIssue.SYSTEM_RETURNED_NO_EVENTS)
            }
            val totals = UsageEventReducer.reduce(records, windowStart, observedEnd, settings.selectedAppPackages)
            if (!totals.initialScreenStateKnown) {
                return@withContext result(MeasurementStatus.PARTIAL, MeasurementIssue.INITIAL_SCREEN_STATE_UNKNOWN)
            }

            val complete = nowMillis >= windowEnd
            result(
                status = if (complete) MeasurementStatus.COMPLETE else MeasurementStatus.PARTIAL,
                issue = MeasurementIssue.NONE,
                nonUse = (totals.nonUseMillis / 60_000L).toInt(),
                distraction = (totals.distractingAppMillis / 60_000L).toInt(),
            )
        } catch (_: SecurityException) {
            result(MeasurementStatus.UNAVAILABLE, MeasurementIssue.USAGE_ACCESS_NOT_GRANTED)
        } catch (_: RuntimeException) {
            result(MeasurementStatus.UNAVAILABLE, MeasurementIssue.QUERY_FAILED)
        }
    }
}
