package com.example.petdetox.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val PetDetoxColors = lightColorScheme(
    primary = Sage,
    onPrimary = WarmPaper,
    secondary = SoftPeach,
    onSecondary = Ink,
    tertiary = Butter,
    background = WarmPaper,
    onBackground = Ink,
    surface = WarmPaper,
    onSurface = Ink,
    onSurfaceVariant = MutedInk,
)

@Composable
fun PetDetoxTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = PetDetoxColors,
        typography = androidx.compose.material3.Typography(),
        content = content,
    )
}
