package com.example.petdetox.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.petdetox.data.local.entity.UsageSnapshotEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UsageSnapshotDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(snapshot: UsageSnapshotEntity): Long

    @Query("SELECT * FROM usage_snapshots ORDER BY measuredAtMillis DESC LIMIT 1")
    fun observeLatest(): Flow<UsageSnapshotEntity?>

    @Query("SELECT * FROM usage_snapshots WHERE periodStartMillis = :periodStartMillis ORDER BY measuredAtMillis DESC LIMIT 1")
    suspend fun getLatestForPeriod(periodStartMillis: Long): UsageSnapshotEntity?

    @Query("DELETE FROM usage_snapshots WHERE measuredAtMillis < :cutoffMillis")
    suspend fun deleteOlderThan(cutoffMillis: Long): Int
}
