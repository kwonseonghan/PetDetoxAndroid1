package com.example.petdetox.domain.growth

import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/** Describes whether the usage data is complete enough to award XP. */
enum class MeasurementStatus {
    COMPLETE,
    PARTIAL,
    UNAVAILABLE,
}

data class GrowthInput(
    val dailyGoalMinutes: Int,
    val nonUseMinutes: Int?,
    val distractionAppMinutes: Int?,
    val dailyAppLimitMinutes: Int,
    val measurementStatus: MeasurementStatus,
)

enum class GrowthFailureReason {
    MEASUREMENT_NOT_COMPLETE,
    MISSING_MEASUREMENT_VALUE,
    INVALID_DAILY_GOAL,
    INVALID_NON_USE_MINUTES,
    INVALID_APP_USAGE_MINUTES,
    INVALID_APP_LIMIT,
}

sealed interface GrowthCalculation {
    data class Success(
        val earnedXp: Int,
        val nonUseRatio: Double,
        val goalMultiplier: Double,
        val distractionMultiplier: Double,
    ) : GrowthCalculation

    data class NotCalculated(val reason: GrowthFailureReason) : GrowthCalculation
}

/**
 * Pure, deterministic XP formula. This class never reads Android usage data or persists rewards.
 * Only a complete measurement can produce an XP result.
 */
object GrowthCalculator {
    fun calculate(input: GrowthInput): GrowthCalculation {
        if (input.measurementStatus != MeasurementStatus.COMPLETE) {
            return GrowthCalculation.NotCalculated(GrowthFailureReason.MEASUREMENT_NOT_COMPLETE)
        }
        if (input.nonUseMinutes == null || input.distractionAppMinutes == null) {
            return GrowthCalculation.NotCalculated(GrowthFailureReason.MISSING_MEASUREMENT_VALUE)
        }
        if (input.dailyGoalMinutes <= 0) {
            return GrowthCalculation.NotCalculated(GrowthFailureReason.INVALID_DAILY_GOAL)
        }
        if (input.nonUseMinutes < 0) {
            return GrowthCalculation.NotCalculated(GrowthFailureReason.INVALID_NON_USE_MINUTES)
        }
        if (input.distractionAppMinutes < 0) {
            return GrowthCalculation.NotCalculated(GrowthFailureReason.INVALID_APP_USAGE_MINUTES)
        }
        if (input.dailyAppLimitMinutes < 0) {
            return GrowthCalculation.NotCalculated(GrowthFailureReason.INVALID_APP_LIMIT)
        }

        val nonUseRatio = min(input.nonUseMinutes.toDouble() / input.dailyGoalMinutes, 1.0)
        val goalMultiplier = 0.5 + (0.5 * nonUseRatio)
        val distractionMultiplier = when {
            input.dailyAppLimitMinutes == 0 && input.distractionAppMinutes == 0 -> 1.0
            input.dailyAppLimitMinutes == 0 -> 0.5
            else -> max(0.5, 1.0 - 0.5 * (input.distractionAppMinutes.toDouble() / input.dailyAppLimitMinutes))
        }
        val earnedXp = floor(
            (input.nonUseMinutes.toDouble() / 5.0) * goalMultiplier * distractionMultiplier,
        ).toInt()

        return GrowthCalculation.Success(
            earnedXp = earnedXp,
            nonUseRatio = nonUseRatio,
            goalMultiplier = goalMultiplier,
            distractionMultiplier = distractionMultiplier,
        )
    }
}
